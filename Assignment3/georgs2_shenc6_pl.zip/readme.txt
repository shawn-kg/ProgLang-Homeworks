Chrisanna Shen (shenc6), Shawn George (georgs2)
Part 1 actually did not take me and my partner very much time at all but part 2 took
a good amount of time. However when we found out how to parse in integers using a DCG
we were able to finish the parser quickly. After that we were working on the 
constraints for a while which we eventually were able to get solutions working for 4 
processors. From there we were able to implement two functions, multList and getValues
that allowed us to get solutions for any amount of processors. Overall it was a tough 
assignment that my partner and I were glad to get through. 